#include "ExpenseManager.h"
#include "ExpenseReport.h"
#include "Colors.h"
#include <iostream>
#include <string>
#include <limits>

int main() {
    ExpenseManager manager;
    ExpenseReport report(&manager);

    report.displayWelcome();

    while (true) {
        std::cout << Colors::CYAN << "\nReport Options:\n" << Colors::RESET;
        std::cout << "1. Summary Report\n";
        std::cout << "2. Daily Expense Chart\n";
        std::cout << "3. Top Spending Category\n";
        std::cout << "4. Export Expenses to CSV\n";
        std::cout << "5. Exit\n";
        std::cout << "Enter your choice: ";

        int choice;
        std::cin >> choice;

        if (std::cin.fail()) {
            std::cin.clear();
            std::cin.ignore(std::numeric_limits<std::streamsize>::max(), '\n');
            report.displayError("Invalid input. Please enter a number.");
            continue;
        }

        int month, year;
        std::string filename;

        switch (choice) {
        case 1:
            std::cout << "Enter month: ";
            std::cin >> month;
            std::cout << "Enter year: ";
            std::cin >> year;
            report.generateSummary(month, year);
            break;

        case 2:
            std::cout << "Enter month: ";
            std::cin >> month;
            std::cout << "Enter year: ";
            std::cin >> year;
            report.generateDailyChart(month, year);
            break;

        case 3:
            std::cout << "Enter month: ";
            std::cin >> month;
            std::cout << "Enter year: ";
            std::cin >> year;
            report.showTopCategory(month, year);
            break;

        case 4:
            std::cout << "Enter month: ";
            std::cin >> month;
            std::cout << "Enter year: ";
            std::cin >> year;
            std::cin.ignore();
            std::cout << "Enter filename (e.g., report.csv): ";
            std::getline(std::cin, filename);
            if (report.exportToCSV(month, year, filename)) {
                report.displaySuccess("Expenses exported to " + filename + " successfully!");
            }
            else {
                report.displayError("Failed to export to CSV.");
            }
            break;

        case 5:
            std::cout << Colors::YELLOW << "Exiting report viewer. Goodbye!" << Colors::RESET << std::endl;
            return 0;

        default:
            report.displayError("Invalid choice. Please select a valid option.");
            break;
        }
    }

    return 0;
}
