#include "ExpenseManager.h"
#include "ExpenseReport.h"
#include "Colors.h"
#include <iostream>
#include <string>

void printReportUsage() {
    std::cout << Colors::CYAN << "Usage:" << Colors::RESET << std::endl;
    std::cout << "  ./expense_report summary <month> <year>" << std::endl;
    std::cout << "  ./expense_report daily_chart <month> <year>" << std::endl;
    std::cout << "  ./expense_report top_category <month> <year>" << std::endl;
    std::cout << "  ./expense_report export_csv <month> <year> <filename>" << std::endl;
}

int main(int argc, char* argv[]) {
    try {
        ExpenseManager manager;
        ExpenseReport report(&manager);

        report.displayWelcome();

        if (argc < 2) {
            std::cout << Colors::RED << "Error: No command specified." << Colors::RESET << std::endl;
            printReportUsage();
            return 1;
        }

        std::string command = argv[1];

        if (command == "summary") {
            if (argc < 4) {
                report.displayError("Insufficient arguments for summary");
                std::cout << "Usage: ./expense_report summary <month> <year>" << std::endl;
                return 1;
            }

            int month = std::stoi(argv[2]);
            int year = std::stoi(argv[3]);
            report.generateSummary(month, year);

        }
        else if (command == "daily_chart") {
            if (argc < 4) {
                report.displayError("Insufficient arguments for daily_chart");
                std::cout << "Usage: ./expense_report daily_chart <month> <year>" << std::endl;
                return 1;
            }

            int month = std::stoi(argv[2]);
            int year = std::stoi(argv[3]);
            report.generateDailyChart(month, year);

        }
        else if (command == "top_category") {
            if (argc < 4) {
                report.displayError("Insufficient arguments for top_category");
                std::cout << "Usage: ./expense_report top_category <month> <year>" << std::endl;
                return 1;
            }

            int month = std::stoi(argv[2]);
            int year = std::stoi(argv[3]);
            report.showTopCategory(month, year);

        }
        else if (command == "export_csv") {
            if (argc < 5) {
                report.displayError("Insufficient arguments for export_csv");
                std::cout << "Usage: ./expense_report export_csv <month> <year> <filename>" << std::endl;
                return 1;
            }

            int month = std::stoi(argv[2]);
            int year = std::stoi(argv[3]);
            std::string filename = argv[4];

            if (report.exportToCSV(month, year, filename)) {
                report.displaySuccess("Expenses exported to " + filename + " successfully!");
            }

        }
        else {
            report.displayError("Unknown command: " + command);
            printReportUsage();
            return 1;
        }

    }
    catch (const std::exception& e) {
        std::cout << Colors::RED << "Fatal Error: " << e.what() << Colors::RESET << std::endl;
        return 1;
    }

    return 0;
}