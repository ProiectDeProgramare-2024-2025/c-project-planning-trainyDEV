#include "ExpenseReport.h"
#include "Colors.h"
#include <iostream>
#include <iomanip>
#include <algorithm>

ExpenseReport::ExpenseReport(ExpenseManager* manager) : manager(manager) {}

void ExpenseReport::printColoredText(const std::string& text, const std::string& color) {
    std::cout << color << text << Colors::RESET;
}

void ExpenseReport::printHeader(const std::string& title) {
    std::cout << "\n" << Colors::BOLD << Colors::CYAN << "=== " << title << " ===" << Colors::RESET << std::endl;
}

std::string ExpenseReport::getBarChart(double value, double maxValue, int width) {
    if (maxValue == 0) return std::string(width, ' ');
    
    int filledWidth = static_cast<int>((value / maxValue) * width);
    std::string bar = Colors::GREEN + std::string(filledWidth, '█') + Colors::RESET;
    bar += std::string(width - filledWidth, '░');
    return bar;
}

void ExpenseReport::generateSummary(int month, int year) {
    printHeader("Monthly Summary for " + std::to_string(month) + "/" + std::to_string(year));
    
    try {
        double totalSpending = manager->getTotalSpending(month, year);
        auto categorySpending = manager->getSpendingByCategory(month, year);
        Expense highestExpense = manager->getHighestExpense(month, year);
        
        if (totalSpending == 0) {
            displayError("No expenses found for the specified month.");
            return;
        }
        
        // Total spending
        std::cout << Colors::BOLD << "Total Spending: " << Colors::GREEN << "$" 
                  << std::fixed << std::setprecision(2) << totalSpending << Colors::RESET << std::endl;
        
        // Category breakdown
        std::cout << "\n" << Colors::BOLD << "Spending by Category:" << Colors::RESET << std::endl;
        for (const auto& pair : categorySpending) {
            double percentage = (pair.second / totalSpending) * 100;
            std::cout << Colors::MAGENTA << std::setw(15) << std::left << pair.first << Colors::RESET
                      << ": " << Colors::GREEN << "$" << std::setw(8) << std::right 
                      << std::fixed << std::setprecision(2) << pair.second << Colors::RESET
                      << " (" << Colors::YELLOW << std::setprecision(1) << percentage << "%" << Colors::RESET << ")" << std::endl;
        }
        
        // Highest expense
        if (highestExpense.getId() != 0) {
            std::cout << "\n" << Colors::BOLD << "Highest Single Expense:" << Colors::RESET << std::endl;
            highestExpense.display();
        }
        
    } catch (const std::exception& e) {
        displayError("Error generating summary: " + std::string(e.what()));
    }
}

void ExpenseReport::generateDailyChart(int month, int year) {
    printHeader("Daily Spending Chart for " + std::to_string(month) + "/" + std::to_string(year));
    
    try {
        auto dailySpending = manager->getDailySpending(month, year);
        
        if (dailySpending.empty()) {
            displayError("No expenses found for the specified month.");
            return;
        }
        
        // Find maximum spending day for scaling
        double maxSpending = 0;
        for (const auto& pair : dailySpending) {
            maxSpending = std::max(maxSpending, pair.second);
        }
        
        std::cout << Colors::BOLD << "Day | Amount    | Chart" << Colors::RESET << std::endl;
        std::cout << Colors::BOLD << "----+-----------+----------------------" << Colors::RESET << std::endl;
        
        for (int day = 1; day <= 31; day++) {
            if (dailySpending.find(day) != dailySpending.end()) {
                double amount = dailySpending[day];
                std::cout << Colors::CYAN << std::setw(2) << day << Colors::RESET
                          << "  | " << Colors::GREEN << "$" << std::setw(8) << std::right 
                          << std::fixed << std::setprecision(2) << amount << Colors::RESET
                          << " | " << getBarChart(amount, maxSpending, 20) << std::endl;
            }
        }
        
    } catch (const std::exception& e) {
        displayError("Error generating daily chart: " + std::string(e.what()));
    }
}

void ExpenseReport::showTopCategory(int month, int year) {
    printHeader("Top Spending Category for " + std::to_string(month) + "/" + std::to_string(year));
    
    try {
        auto categorySpending = manager->getSpendingByCategory(month, year);
        
        if (categorySpending.empty()) {
            displayError("No expenses found for the specified month.");
            return;
        }
        
        auto topCategory = std::max_element(categorySpending.begin(), categorySpending.end(),
                                          [](const auto& a, const auto& b) {
                                              return a.second < b.second;
                                          });
        
        std::cout << Colors::BOLD << "Top Category: " << Colors::MAGENTA << topCategory->first << Colors::RESET << std::endl;
        std::cout << Colors::BOLD << "Total Amount: " << Colors::GREEN << "$" 
                  << std::fixed << std::setprecision(2) << topCategory->second << Colors::RESET << std::endl;
        
    } catch (const std::exception& e) {
        displayError("Error finding top category: " + std::string(e.what()));
    }
}

bool ExpenseReport::exportToCSV(int month, int year, const std::string& filename) {
    return manager->exportToCSV(month, year, filename);
}

// crazy display I know
void ExpenseReport::displayWelcome() {
    std::cout << "====================================\n"
        << "      Personal Expense Tracker      \n"
        << "====================================\n\n";
}

void ExpenseReport::displayError(const std::string& error) {
    std::cout << Colors::RED << " Error: " << error << Colors::RESET << std::endl;
}

void ExpenseReport::displaySuccess(const std::string& message) {
    std::cout << Colors::GREEN << "Success! " << message << Colors::RESET << std::endl;
}
