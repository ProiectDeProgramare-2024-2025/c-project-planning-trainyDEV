#ifndef EXPENSE_H
#define EXPENSE_H

#include <string>
#include <iostream>
#include <iomanip>

class Expense {
private:
    int id;
    double amount;
    std::string category;
    int day, month, year;
    std::string note;

public:
    // Constructors
    Expense();
    Expense(int id, double amount, const std::string& category, 
            int day, int month, int year, const std::string& note);

    // Getters
    int getId() const { return id; }
    double getAmount() const { return amount; }
    std::string getCategory() const { return category; }
    int getDay() const { return day; }
    int getMonth() const { return month; }
    int getYear() const { return year; }
    std::string getNote() const { return note; }

    // Setters
    void setId(int id) { this->id = id; }
    void setAmount(double amount) { this->amount = amount; }
    void setCategory(const std::string& category) { this->category = category; }
    void setDay(int day) { this->day = day; }
    void setMonth(int month) { this->month = month; }
    void setYear(int year) { this->year = year; }
    void setNote(const std::string& note) { this->note = note; }

    // Utility methods
    std::string getDateString() const;
    std::string toString() const;
    void display() const;
    
    std::string toFileFormat() const;
    static Expense fromFileFormat(const std::string& line);
};

#endif
