#include "ExpenseManager.h"
#include "Colors.h"
#include <fstream>
#include <iostream>
#include <algorithm>
#include <stdexcept>

ExpenseManager::ExpenseManager(const std::string& filename) : filename(filename), nextId(1) {
    try {
        loadFromFile();
    } catch (const std::exception& e) {
        std::cout << Colors::YELLOW << "Warning: Could not load existing data. Starting fresh." << Colors::RESET << std::endl;
    }
}

void ExpenseManager::loadFromFile() {
    std::ifstream file(filename);
    if (!file.is_open()) {
        return; // File doesn't exist yet, that's okay :)
    }
    
    std::string line;
    expenses.clear();
    int maxId = 0;
    
    while (std::getline(file, line)) {
        if (line.empty()) continue;
        
        try {
            Expense expense = Expense::fromFileFormat(line);
            expenses.push_back(expense);
            maxId = std::max(maxId, expense.getId());
        } catch (const std::exception& e) {
            std::cout << Colors::YELLOW << "Warning: Skipping invalid line in file." << Colors::RESET << std::endl;
        }
    }
    
    nextId = maxId + 1;
    file.close();
}

void ExpenseManager::saveToFile() {
    std::ofstream file(filename);
    if (!file.is_open()) {
        throw std::runtime_error("Could not open file for writing");
    }
    
    for (const auto& expense : expenses) {
        file << expense.toFileFormat() << std::endl;
    }
    
    file.close();
}

int ExpenseManager::getNextId() {
    return nextId++;
}

bool ExpenseManager::isValidDate(int day, int month, int year) {
    if (year < 1900 || year > 2100) return false;
    if (month < 1 || month > 12) return false;
    if (day < 1 || day > 31) return false;
    
    // Simple validation - could be enhanced but I'm lazy
    int daysInMonth[] = {31, 28, 31, 30, 31, 30, 31, 31, 30, 31, 30, 31};
	// Leap year checker
    if (year % 4 == 0 && (year % 100 != 0 || year % 400 == 0)) {
        daysInMonth[1] = 29; 
    }
    
    return day <= daysInMonth[month - 1];
}

bool ExpenseManager::isValidAmount(double amount) {
    return amount > 0.0 && amount < 1000000.0; // Reasonable limits
}

bool ExpenseManager::addExpense(double amount, const std::string& category, 
                               int day, int month, int year, const std::string& note) {
    try {
        if (!isValidAmount(amount)) {
            throw std::invalid_argument("Invalid amount");
        }
        
        if (!isValidDate(day, month, year)) {
            throw std::invalid_argument("Invalid date");
        }
        
        if (category.empty()) {
            throw std::invalid_argument("Category cannot be empty");
        }
        
        Expense expense(getNextId(), amount, category, day, month, year, note);
        expenses.push_back(expense);
        saveToFile();
        
        return true;
    } catch (const std::exception& e) {
        std::cout << Colors::RED << "Error adding expense: " << e.what() << Colors::RESET << std::endl;
        return false;
    }
}

bool ExpenseManager::deleteExpense(int id) {
    try {
        auto it = std::find_if(expenses.begin(), expenses.end(),
                              [id](const Expense& e) { return e.getId() == id; });
        
        if (it == expenses.end()) {
            throw std::invalid_argument("Expense not found");
        }
        
        expenses.erase(it);
        saveToFile();
        
        return true;
    } catch (const std::exception& e) {
        std::cout << Colors::RED << "Error deleting expense: " << e.what() << Colors::RESET << std::endl;
        return false;
    }
}

bool ExpenseManager::modifyExpense(int id, double amount, const std::string& category,
                                  int day, int month, int year, const std::string& note) {
    try {
        auto it = std::find_if(expenses.begin(), expenses.end(),
                              [id](const Expense& e) { return e.getId() == id; });
        
        if (it == expenses.end()) {
            throw std::invalid_argument("Expense not found");
        }
        
        if (!isValidAmount(amount) || !isValidDate(day, month, year) || category.empty()) {
            throw std::invalid_argument("Invalid expense data");
        }
        
        it->setAmount(amount);
        it->setCategory(category);
        it->setDay(day);
        it->setMonth(month);
        it->setYear(year);
        it->setNote(note);
        
        saveToFile();
        return true;
    } catch (const std::exception& e) {
        std::cout << Colors::RED << "Error modifying expense: " << e.what() << Colors::RESET << std::endl;
        return false;
    }
}

void ExpenseManager::viewAllExpenses(int month, int year) {
    std::vector<Expense> monthlyExpenses = getExpensesForMonth(month, year);
    
    if (monthlyExpenses.empty()) {
        std::cout << Colors::YELLOW << "No expenses found for " << month << "/" << year << Colors::RESET << std::endl;
        return;
    }
    
    std::cout << Colors::BOLD << Colors::CYAN << "\n=== Expenses for " << month << "/" << year << " ===" << Colors::RESET << std::endl;
    for (const auto& expense : monthlyExpenses) {
        expense.display();
    }
    std::cout << Colors::CYAN << "Total expenses: " << monthlyExpenses.size() << Colors::RESET << std::endl;
}

std::vector<Expense> ExpenseManager::getExpensesForMonth(int month, int year) {
    std::vector<Expense> result;
    
    for (const auto& expense : expenses) {
        if (expense.getMonth() == month && expense.getYear() == year) {
            result.push_back(expense);
        }
    }
    
    return result;
}

double ExpenseManager::getTotalSpending(int month, int year) {
    double total = 0.0;
    for (const auto& expense : expenses) {
        if (expense.getMonth() == month && expense.getYear() == year) {
            total += expense.getAmount();
        }
    }
    return total;
}

std::map<std::string, double> ExpenseManager::getSpendingByCategory(int month, int year) {
    std::map<std::string, double> categorySpending;
    
    for (const auto& expense : expenses) {
        if (expense.getMonth() == month && expense.getYear() == year) {
            categorySpending[expense.getCategory()] += expense.getAmount();
        }
    }
    
    return categorySpending;
}

Expense ExpenseManager::getHighestExpense(int month, int year) {
    Expense highest;
    double maxAmount = 0.0;
    
    for (const auto& expense : expenses) {
        if (expense.getMonth() == month && expense.getYear() == year) {
            if (expense.getAmount() > maxAmount) {
                maxAmount = expense.getAmount();
                highest = expense;
            }
        }
    }
    
    return highest;
}

std::map<int, double> ExpenseManager::getDailySpending(int month, int year) {
    std::map<int, double> dailySpending;
    
    for (const auto& expense : expenses) {
        if (expense.getMonth() == month && expense.getYear() == year) {
            dailySpending[expense.getDay()] += expense.getAmount();
        }
    }
    
    return dailySpending;
}

bool ExpenseManager::exportToCSV(int month, int year, const std::string& csvFilename) {
    try {
        std::ofstream file(csvFilename);
        if (!file.is_open()) {
            throw std::runtime_error("Could not create CSV file");
        }
        
        // Write header
        file << "ID,Date,Category,Amount,Note\n";
        
        // Write data
        std::vector<Expense> monthlyExpenses = getExpensesForMonth(month, year);
        for (const auto& expense : monthlyExpenses) {
            file << expense.getId() << ","
                 << expense.getDateString() << ","
                 << expense.getCategory() << ","
                 << std::fixed << std::setprecision(2) << expense.getAmount() << ","
                 << expense.getNote() << "\n";
        }
        
        file.close();
        return true;
    } catch (const std::exception& e) {
        std::cout << Colors::RED << "Error exporting to CSV: " << e.what() << Colors::RESET << std::endl;
        return false;
    }
}