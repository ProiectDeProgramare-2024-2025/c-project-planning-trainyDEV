#include "ExpenseManager.h"
#include "ExpenseReport.h"
#include "Colors.h"
#include <iostream>
#include <string>
#include <limits>

int main() {
    ExpenseManager manager;
    ExpenseReport report(&manager);

    report.displayWelcome();

    while (true) {
        std::cout << Colors::CYAN << "\nChoose an option:\n" << Colors::RESET;
        std::cout << "1. Add Expense\n";
        std::cout << "2. Delete Expense\n";
        std::cout << "3. Modify Expense\n";
        std::cout << "4. View All Expenses\n";
        std::cout << "5. Exit\n";
        std::cout << "Enter your choice: ";

        int choice;
        std::cin >> choice;

        if (std::cin.fail()) {
            std::cin.clear();
            std::cin.ignore(std::numeric_limits<std::streamsize>::max(), '\n');
            report.displayError("Invalid input. Please enter a number.");
            continue;
        }

        switch (choice) {
        case 1: {
            double amount;
            std::string category, note;
            int day, month, year;

            std::cout << "Amount: ";
            std::cin >> amount;
            std::cout << "Category: ";
            std::cin >> category;
            std::cout << "Day: ";
            std::cin >> day;
            std::cout << "Month: ";
            std::cin >> month;
            std::cout << "Year: ";
            std::cin >> year;
            std::cin.ignore(); // Clear newline
            std::cout << "Note (optional): ";
            std::getline(std::cin, note);

            if (manager.addExpense(amount, category, day, month, year, note)) {
                report.displaySuccess("Expense added successfully!");
            }
            else {
                report.displayError("Failed to add expense.");
            }
            break;
        }
        case 2: {
            int id;
            std::cout << "Expense ID to delete: ";
            std::cin >> id;

            if (manager.deleteExpense(id)) {
                report.displaySuccess("Expense deleted successfully!");
            }
            else {
                report.displayError("Expense not found.");
            }
            break;
        }
        case 3: {
            int id, day, month, year;
            double amount;
            std::string category, note;

            std::cout << "Expense ID to modify: ";
            std::cin >> id;
            std::cout << "New Amount: ";
            std::cin >> amount;
            std::cout << "New Category: ";
            std::cin >> category;
            std::cout << "New Day: ";
            std::cin >> day;
            std::cout << "New Month: ";
            std::cin >> month;
            std::cout << "New Year: ";
            std::cin >> year;
            std::cin.ignore();
            std::cout << "New Note (optional): ";
            std::getline(std::cin, note);

            if (manager.modifyExpense(id, amount, category, day, month, year, note)) {
                report.displaySuccess("Expense modified successfully!");
            }
            else {
                report.displayError("Expense not found or could not be modified.");
            }
            break;
        }
        case 4: {
            int month, year;
            std::cout << "Enter month: ";
            std::cin >> month;
            std::cout << "Enter year: ";
            std::cin >> year;

            manager.viewAllExpenses(month, year);
            break;
        }
        case 5:
            std::cout << Colors::YELLOW << "Exiting." << Colors::RESET << std::endl;
            return 0;
        default:
            report.displayError("Invalid option. Please choose a number between 1 and 5.");
        }
    }

    return 0;
}
