#include "ExpenseManager.h"
#include "ExpenseReport.h"
#include "Colors.h"
#include <iostream>
#include <string>
#include <sstream>

void printUsage() {
    std::cout << Colors::CYAN << "Usage:" << Colors::RESET << std::endl;
    std::cout << "  ./expense_logger add_expense <amount> <category> <day> <month> <year> [note]" << std::endl;
    std::cout << "  ./expense_logger delete_expense <id>" << std::endl;
    std::cout << "  ./expense_logger modify_expense <id> <amount> <category> <day> <month> <year> [note]" << std::endl;
    std::cout << "  ./expense_logger view_all <month> <year>" << std::endl;
}

int main(int argc, char* argv[]) {
    try {
        ExpenseManager manager;
        ExpenseReport report(&manager);

        report.displayWelcome();

        if (argc < 2) {
            std::cout << Colors::RED << "Error: No command specified." << Colors::RESET << std::endl;
            printUsage();
            return 1;
        }

        std::string command = argv[1];

        if (command == "add_expense") {
            if (argc < 7) {
                report.displayError("Insufficient arguments for add_expense");
                std::cout << "Usage: ./expense_logger add_expense <amount> <category> <day> <month> <year> [note]" << std::endl;
                return 1;
            }

            double amount = std::stod(argv[2]);
            std::string category = argv[3];
            int day = std::stoi(argv[4]);
            int month = std::stoi(argv[5]);
            int year = std::stoi(argv[6]);
            std::string note = (argc > 7) ? argv[7] : "";

            if (manager.addExpense(amount, category, day, month, year, note)) {
                report.displaySuccess("Expense added successfully!");
            }

        }
        else if (command == "delete_expense") {
            if (argc < 3) {
                report.displayError("Insufficient arguments for delete_expense");
                std::cout << "Usage: ./expense_logger delete_expense <id>" << std::endl;
                return 1;
            }

            int id = std::stoi(argv[2]);
            if (manager.deleteExpense(id)) {
                report.displaySuccess("Expense deleted successfully!");
            }

        }
        else if (command == "modify_expense") {
            if (argc < 8) {
                report.displayError("Insufficient arguments for modify_expense");
                std::cout << "Usage: ./expense_logger modify_expense <id> <amount> <category> <day> <month> <year> [note]" << std::endl;
                return 1;
            }

            int id = std::stoi(argv[2]);
            double amount = std::stod(argv[3]);
            std::string category = argv[4];
            int day = std::stoi(argv[5]);
            int month = std::stoi(argv[6]);
            int year = std::stoi(argv[7]);
            std::string note = (argc > 8) ? argv[8] : "";

            if (manager.modifyExpense(id, amount, category, day, month, year, note)) {
                report.displaySuccess("Expense modified successfully!");
            }

        }
        else if (command == "view_all") {
            if (argc < 4) {
                report.displayError("Insufficient arguments for view_all");
                std::cout << "Usage: ./expense_logger view_all <month> <year>" << std::endl;
                return 1;
            }

            int month = std::stoi(argv[2]);
            int year = std::stoi(argv[3]);
            manager.viewAllExpenses(month, year);

        }
        else {
            report.displayError("Unknown command: " + command);
            printUsage();
            return 1;
        }

    }
    catch (const std::exception& e) {
        std::cout << Colors::RED << "Fatal Error: " << e.what() << Colors::RESET << std::endl;
        return 1;
    }

    return 0;
}