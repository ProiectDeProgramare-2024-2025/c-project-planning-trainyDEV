#ifndef EXPENSE_MANAGER_H
#define EXPENSE_MANAGER_H

#include "Expense.h"
#include <vector>
#include <string>
#include <map>

class ExpenseManager {
private:
    std::vector<Expense> expenses;
    std::string filename;
    int nextId;

    // Helper methods
    void loadFromFile();
    void saveToFile();
    int getNextId();
    bool isValidDate(int day, int month, int year);
    bool isValidAmount(double amount);

public:
    // Constructor
    ExpenseManager(const std::string& filename = "expenses.txt");

    // Core functionality
    bool addExpense(double amount, const std::string& category, 
                   int day, int month, int year, const std::string& note);
    bool deleteExpense(int id);
    bool modifyExpense(int id, double amount, const std::string& category,
                      int day, int month, int year, const std::string& note);
    
    // View methods
    void viewAllExpenses(int month, int year);
    std::vector<Expense> getExpensesForMonth(int month, int year);
    
    // Report methods (relation with ExpenseReport class)
    double getTotalSpending(int month, int year);
    std::map<std::string, double> getSpendingByCategory(int month, int year);
    Expense getHighestExpense(int month, int year);
    std::map<int, double> getDailySpending(int month, int year);
    
    // Utility
    void displayAllExpenses();
    bool exportToCSV(int month, int year, const std::string& csvFilename);
};

#endif