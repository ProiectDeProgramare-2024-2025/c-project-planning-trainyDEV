#ifndef EXPENSE_REPORT_H
#define EXPENSE_REPORT_H

#include "ExpenseManager.h"
#include <map>

class ExpenseReport {
private:
    ExpenseManager* manager;

    // Helper methods for visualization
    void printColoredText(const std::string& text, const std::string& color);
    void printHeader(const std::string& title);
    std::string getBarChart(double value, double maxValue, int width = 20);

public:
    // Constructor - establishes relationship with ExpenseManager
    ExpenseReport(ExpenseManager* manager);

    void generateSummary(int month, int year);
    void generateDailyChart(int month, int year);
    void showTopCategory(int month, int year);
    bool exportToCSV(int month, int year, const std::string& filename);
    
    void displayWelcome();
    void displayError(const std::string& error);
    void displaySuccess(const std::string& message);
};

#endif