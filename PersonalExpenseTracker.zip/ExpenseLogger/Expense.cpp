#include "Expense.h"
#include "Colors.h"
#include <vector>   
#include <string>     
#include <stdexcept>  
#include <iostream> 
#include <sstream>
#include <iomanip>

Expense::Expense() : id(0), amount(0.0), category(""), day(1), month(1), year(2025), note("") {}

Expense::Expense(int id, double amount, const std::string& category, 
                int day, int month, int year, const std::string& note)
    : id(id), amount(amount), category(category), day(day), month(month), year(year), note(note) {}

std::string Expense::getDateString() const {
    std::ostringstream oss;
    oss << std::setfill('0') << std::setw(2) << day << "/"
        << std::setfill('0') << std::setw(2) << month << "/"
        << year;
    return oss.str();
}

std::string Expense::toString() const {
    std::ostringstream oss;
    oss << "ID: " << id << " | Date: " << getDateString() 
        << " | Category: " << category << " | Amount: $" << std::fixed << std::setprecision(2) << amount
        << " | Note: " << note;
    return oss.str();
}

void Expense::display() const {
    std::cout << Colors::CYAN << "ID: " << Colors::YELLOW << id << Colors::RESET
              << Colors::CYAN << " | Date: " << Colors::WHITE << getDateString() << Colors::RESET
              << Colors::CYAN << " | Category: " << Colors::MAGENTA << category << Colors::RESET
              << Colors::CYAN << " | Amount: " << Colors::GREEN << "$" << std::fixed << std::setprecision(2) << amount << Colors::RESET
              << Colors::CYAN << " | Note: " << Colors::WHITE << note << Colors::RESET << std::endl;
}

std::string Expense::toFileFormat() const {
    std::ostringstream oss;
    oss << id << ";" << getDateString() << ";" << category << ";" 
        << std::fixed << std::setprecision(2) << amount << ";" << note;
    return oss.str();
}

Expense Expense::fromFileFormat(const std::string& line) {
    std::istringstream iss(line);
    std::string token;
    std::vector<std::string> tokens;
    
    while (std::getline(iss, token, ';')) {
        tokens.push_back(token);
    }
    
    if (tokens.size() != 5) {
        throw std::invalid_argument("Invalid file format");
    }
    
    int id = std::stoi(tokens[0]);
    
    // Parse date
    std::istringstream dateStream(tokens[1]);
    std::string dayStr, monthStr, yearStr;
    std::getline(dateStream, dayStr, '/');
    std::getline(dateStream, monthStr, '/');
    std::getline(dateStream, yearStr);
    
    int day = std::stoi(dayStr);
    int month = std::stoi(monthStr);
    int year = std::stoi(yearStr);
    
    std::string category = tokens[2];
    double amount = std::stod(tokens[3]);
    std::string note = tokens[4];
    
    return Expense(id, amount, category, day, month, year, note);
}